<?php 
    require './check_session.php';
	require './dbConn.php';
	
	dbConnect();
	$qry = "UPDATE `dbomarmohamed`.`richiesteamicizia` SET `state` = 2  WHERE `richiesteamicizia`.`sender` = '".$_GET['sender']."' AND `richiesteamicizia`.`receiver` = '".$_SESSION['username']."'";
	$check = mysql_query($qry);
	
	header("Location: ../notice.php");
?>