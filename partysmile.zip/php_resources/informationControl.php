<?php 																				

$flag=true;
$emptyString = "";
	
	$qry2 = "SELECT email,username FROM utenti WHERE email = '".$_POST['email']."'";
    $check2 = mysql_query($qry2);
    $info2 = mysql_fetch_row($check2);
	
	$info2[0]= stripslashes($info2[0]);
	$info2[1]= stripslashes($info2[1]);
	
	$pattern = '/[|+--\'=<>!=()%*]/i';
	$patternMail = '/\S+@\S+\.\S+/';
	$patternDate = '/^\d{2}[-]\d{2}[-]\d{4}$/';
  
  
if((preg_match($pattern,$_POST["sentimentalsituation"])===0))
	if((preg_match($pattern,$_POST["actualcity"])===0))
		if((preg_match($pattern,$_POST["birthcity"])===0))
			if((preg_match($pattern,$_POST["surname"])===0))
				if((preg_match($pattern,$_POST["name"])===0))
					if((preg_match($patternDate,$_POST["birthdate"])===1))
    if ((($_POST['email'] == $info2[0]) && ($_SESSION['username']== $info2[1])) | ($_POST['email'] != $info2[0]) | $_POST['email'] == $emptyString)
					if((preg_match($pattern,$_POST["passwd"])===0))
						if((strlen($_POST["passwd"])>=5) && (strlen($_POST["passwd"])<=15))
							if((preg_match($patternMail,$_POST["email"])===1))
								$flag=true;
							else{
								$flag=false;
								$errorMessage3="[SERVER-SIDE CHECK] Inserisci un indirizzo email con un formato corretto. Esempio: (studente@ateneo.com)";
							 	}
						else{
							$flag=false; 
							$errorMessage3="[SERVER-SIDE CHECK] La password deve avere una lunghezza compresa tra 5 e 15 caratteri.";
							}
					else{
						$flag=false;
						$errorMessage3="[SERVER-SIDE CHECK] La password non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
						}
		  		else{
					$flag=false;
					$errorMessage3="[SERVER-SIDE CHECK] Email già utilizzata da un altro utente. Perfavore, inserisci un altro indirizzo di posta elettronica."; 
    				} 
	
			else{
				$flag=false;
				$errorMessage3="[SERVER-SIDE CHECK] Inserisci la tua data di nascita con un formato corretto. Esempio: (GG-MM-AAAA)."; 
			    } 
		  else{
			 $flag=false;
			 $errorMessage3="[SERVER-SIDE CHECK] Il tuo nome reale non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
			  }
	  else{
		 $flag=false;
		 $errorMessage3="[SERVER-SIDE CHECK] Il tuo cognome non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
		  }
  else{
	 $flag=false;
	 $errorMessage3="[SERVER-SIDE CHECK] Il nome della tua città di nascita non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
	  }
 else{
	$flag=false;
	$errorMessage3="[SERVER-SIDE CHECK] Il nome della città dove vivi attualmente non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
	}
else{
	$flag=false;
	$errorMessage3="[SERVER-SIDE CHECK] La descrizione della tua situazione sentimentale attuale non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
	}
	
	 
	 ?>