<?php

session_start();

    //Confronto password dell'utente e quella presente nel database. Se non corrispondono, la password dell'utente viene eliminata dalle variabili di sessione

    if($_SESSION['password'] == $db_pass['password']) { 
		return;
        
    } else {
        unset($_SESSION['username']);
        unset($_SESSION['password']);
    }


?>