<?php
$flag=true;
$emptyString = "";

$pattern = '/[|+--\'=<>!=()%*]/i';

	dbConnect();
    $qry = "SELECT username FROM utenti WHERE username = '".$_POST['uname']."'";
    $check = mysql_query($qry);
    $info = mysql_fetch_row($check);
	mysql_close();
	
	$info[0] = stripslashes($info[0]);


    if((preg_match($pattern,$_POST["uname"])===0))
		if((strlen($_POST["uname"])>=5) && (strlen($_POST["uname"])<=15))
					if ($_POST['uname'] == $info[0])
							$flag=true;
					else{
						$flag=false;
        				$errorMessage2="[SERVER-SIDE CHECK] Username non presente tra gli utenti iscritti.";
						
  					    } 
		else{
			$flag=false;
			 $errorMessage2="[SERVER-SIDE CHECK] L'username deve avere una lunghezza compresa tra 5 e 15 caratteri.";
			}	
	else{

		$flag=false;
		 $errorMessage2="[SERVER-SIDE CHECK] L'username non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
		}
	
?>