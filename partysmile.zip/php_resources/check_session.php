<?php
session_start();

if (!isset($_SESSION["logged_in"])) {
?>
<script type="text/javascript">
location.replace("notloggedin.php")
</script>
<?php 
}
else if(isset($_SESSION["logged_in"])&&$_SESSION["validated"]==0) {
?>
<script type="text/javascript">
location.replace("waitingvalidation.php")
</script>
<?php 
}

?>