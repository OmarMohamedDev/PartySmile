<?php
$flag=true;
$emptyString = "";

$pattern = '/[|+--\'=<>!=()%*]/i';
$patternMail = '/\S+@\S+\.\S+/';

if (isset($_GET['uname'])){

    $qry = "SELECT username FROM utenti WHERE username = '".$_GET['uname']."'";
    $check = mysql_query($qry);
    $info = mysql_fetch_row($check);
	
	$info[0] = stripslashes($info[0]);

    if((preg_match($pattern,$_GET["uname"])===0))
		if((strlen($_GET["uname"])>=5) && (strlen($_GET["uname"])<=15))
					if ($_GET['uname'] == $info[0])
							$flag=true;
					else{
						$flag=false;
        				$errorMessage2="[SERVER-SIDE CHECK]Username non presente tra gli utenti iscritti.";
						
  					    } 
		else{
			$flag=false;
			 $errorMessage2="[SERVER-SIDE CHECK]L'username deve avere una lunghezza compresa tra 5 e 15 caratteri.";
			}	
	else{

		$flag=false;
		 $errorMessage2="[SERVER-SIDE CHECK]L'username non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
		}
		
}

if (isset($_GET['email'])){

	$qry2 = "SELECT email,username FROM utenti WHERE email = '".$_GET['email']."'";
    $check2 = mysql_query($qry2);
    $info2 = mysql_fetch_row($check2);
	
	$info2[0]= stripslashes($info2[0]);
	$info2[1]= stripslashes($info2[1]);

		if ((($_GET['email'] == $info2[0]) && ($_SESSION['username']!= $info2[1])))
					if((preg_match($patternMail,$_GET["email"])===1))
							$flag=true;
					else{
						$flag=false;
        				$errorMessage2="[SERVER-SIDE CHECK]Inserisci un indirizzo email con un formato corretto. Esempio: (studente@ateneo.com)";
						
  					    } 
				else{
					$flag=false;
					$errorMessage2="[SERVER-SIDE CHECK]Indirizzo email non appartenente a nessun altro utente di PartySmile. Perfavore, inserisci un altro indirizzo di GETa elettronica."; 
    				} 	
		
}

if (isset($_GET['actualcity'])){

					if((preg_match($pattern,$_GET["actualcity"])===0))
							$flag=true;
					 else{
						$flag=false;
						$errorMessage2="[SERVER-SIDE CHECK]Il nome della città dove vive attualmente l'utente da te ricercato non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
	}
		
}

if (isset($_GET['name'])){
	
	$qry = "SELECT name, surname FROM utenti WHERE name = '".$_GET['name']."'";
    $check = mysql_query($qry);
    $info = mysql_fetch_row($check);
	
	$info[0] = stripslashes($info[0]);

if ((($_GET['name'] == $info[0])))
					if((preg_match($pattern,$_GET["name"])===0))
							$flag=true;
					 else{
			 			$flag=false;
						 $errorMessage2="[SERVER-SIDE CHECK]Il nome reale della persona che stai ricercando non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
						  }
		   else{
					 $flag=false;
					 $errorMessage2="[SERVER-SIDE CHECK]Non esiste nessun utente con questo nome.";
		  }
		
}

if (isset($_GET['surname'])){
	
	$qry = "SELECT name, surname FROM utenti WHERE surname = '".$_GET['surname']."'";
    $check = mysql_query($qry);
    $info = mysql_fetch_row($check);
	
	$info[1] = stripslashes($info[1]);

if ((($_GET['surname'] == $info[1])))
				if((preg_match($pattern,$_GET["surname"])===0))
							$flag=true;
	 			 else{
					 $flag=false;
					 $errorMessage2="[SERVER-SIDE CHECK] Il cognome della persona che stai ricercando non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
		  }
		  
		   else{
					 $flag=false;
					 $errorMessage2="[SERVER-SIDE CHECK] Non esiste nessun utente con questo cognome.";
		  }
		
}
	
?>