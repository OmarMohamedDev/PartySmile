<?php
$flag=true;
$flagMySqlConnect=true;
$flagSelectDb=true;

$pattern = '/[|+--\'=<>!=()%*]/i';
    
if((preg_match($pattern,$_POST["password"])===0))
    if((preg_match($pattern,$_POST["password"])===0))
		if((strlen($_POST["nomehost"])>=5) && (strlen($_POST["nomehost"])<=50))
			if((preg_match($pattern,$_POST["nomedb"])===0))
							$flag=true;
			else{
				$flag=false;
				$errorMessage2="[SERVER-SIDE CHECK] Il nome db non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
				}
		else{
			$flag=false;
			 $errorMessage2="[SERVER-SIDE CHECK] Il nome host deve avere una lunghezza compresa tra 5 e 50 caratteri.";
			}	
	else{
		$flag=false;
		 $errorMessage2="[SERVER-SIDE CHECK] La password non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
		}
else{
		$flag=false;
		 $errorMessage2="[SERVER-SIDE CHECK] L'username non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
		}
		
		$db= mysql_connect(''.$_POST['nomehost'].'',''.$_POST['username'].'',''.$_POST['password'].'')
        or $flagMySqlConnect=false;

		mysql_select_db("".$_POST['nomedb']."", $db)
        or  $flagSelectDb=false;
		
		if($flagMySqlConnect==false){
			$flag=false;
			$errorMessage2="Connessione non riuscita: " . mysql_error();
		}
		
		if($flagSelectDb==false){
			$flag=false;
			$errorMessage2= "Selezione del database non riuscita";
		}
	
?>