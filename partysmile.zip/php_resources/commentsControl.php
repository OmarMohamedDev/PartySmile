<?php
$flag=true;

$pattern = '/[|+--\'=<>!=()%*]/i';
      
			if((preg_match($pattern,$_GET["commentsText"])===0))
				if((strlen($_GET["commentsText"])>=1) && (strlen($_GET["commentsText"])<=140))
							$flag=true;
				else{
					$flag=false;
					$errorMessage2="[SERVER-SIDE CHECK] Il commento deve avere una lunghezza compresa tra 1 e 140 caratteri.";
					}
			else{
				$flag=false;
				$errorMessage2="[SERVER-SIDE CHECK] Il commento non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
				}
	
?>