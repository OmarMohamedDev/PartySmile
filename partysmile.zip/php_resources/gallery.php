<?php

global $actualImageIndex; 

 ?>

<script type="text/javascript">
    
    //Variabili globali utilizzate all'interno del tag script 
var galleryDiv;
var tempImg;
var parent;
var actualImageIndex;

var commentsDiv
var commentsForm;
var commentsSubmitButton;
var commentsFormData;

var username= "<?php echo $_SESSION['username'] ?>";

      function openGallery(src,srcIndex){ 
          //funzione che crea un div al cui interno verrà caricata la preview delle immagini degli utenti
          
        
        galleryDiv = document.createElement("div");
        /* Creazione del div "principale" che conterra' tutti gli altri elementi della preview
        * Lo stile dell'elemento e' stato definito nel file sitestyle.css
        */
        galleryDiv.id="galleryDiv";
		galleryDiv.setAttribute("align","center");

        parent=document.getElementById('content');
        parent.insertBefore(galleryDiv,parent.firstChild);
        
        //inserimento di galleryDiv nel DOM come child del div content
        
                tempImg = document.createElement('img');
                tempImg.setAttribute('id','tempImage')
				tempImg.setAttribute('alt','tempImage')
                tempImg.src=src;
                actualImageIndex=srcIndex;

        galleryDiv.appendChild(tempImg);
        //inserimento di tempImg nel DOM come child del div galleryDiv
		
		buttonDiv = document.createElement("div");
        buttonDiv.setAttribute("align","center");
        buttonDiv.style.position="static";
        buttonDiv.style.backgroundColor="#FBBE64";
        buttonDiv.style.width="400px";
		galleryDiv.appendChild(buttonDiv);
        

        var backButton= document.createElement('input');
        backButton.setAttribute('type',"button");
        backButton.setAttribute('value',"<---------------- Precedente");
        backButton.addEventListener("click",goBack,false);
        galleryDiv.appendChild(backButton); 
        /*creazione del backbutton, che permette di tornare indietro
         * all'interno della preview. Il bottone e' inserito nel DOM
         * come child di galleryDiv
         */

        var closeButton= document.createElement('input');
        closeButton.setAttribute('type',"button");
        closeButton.setAttribute('value',"Chiudi");
        closeButton.addEventListener("click",closeGallery,false);
        galleryDiv.appendChild(closeButton); 
        /*creazione del closeButton, che permette di chiudere
         *la preview. Il bottone e' inserito nel DOM
         * come child di galleryDiv
         */

        var nextButton= document.createElement('input');
        nextButton.setAttribute('type',"button");
        nextButton.setAttribute('value',"Successiva ----------------->");
        nextButton.addEventListener("click",goNext,false);
        galleryDiv.appendChild(nextButton); 
        /*creazione del nextbutton, che permette di andare avanti
         * all'interno della preview. Il bottone e' inserito nel DOM
         * come child di galleryDiv
         */
           
        // IMPLEMENTAZIONE DELL'AREA DEL DIV DEDICATA AI COMMENTI ALLE IMMAGINI DELLA PREVIEW
    
        commentsDiv = document.createElement("div");
        commentsDiv.setAttribute("align","center");
        commentsDiv.style.position="static";
        commentsDiv.style.backgroundColor="#FBBE64";
        commentsDiv.style.width="400px"; 
        
        galleryDiv.appendChild(commentsDiv);
        /*creazione del div sotto cui verrà attaccato il form dei commenti
         * ed i commenti stessi. 
         */

        var commentsTitle =document.createTextNode('Inserisci un commento a questa immagine:');
        commentsDiv.appendChild(commentsTitle);
        /*Div che divide l'area dei bottoni di navigazione
         * all'interno della preview dall'area riservata all'inserimento ed alla
         * visualizzazione dei commenti
         */
        
        commentsForm=document.createElement('form');
        commentsForm.setAttribute('method',"get");
        //creazione del form per l'inserimento dei commenti
         
        var commentsText=document.createElement('input');
        commentsText.setAttribute('type',"text");
        commentsText.setAttribute('id',"commentsMessage");
        commentsForm.appendChild(commentsText);
        //area di testo dove immettere il contenuto del commento
        
        commentsSubmitButton=document.createElement('input');
        commentsSubmitButton.setAttribute('type',"button");
        commentsSubmitButton.setAttribute('value',"Invia");
        commentsSubmitButton.addEventListener("click",saveComment,false);
        commentsForm.appendChild(commentsSubmitButton);
        /*Button invia che permette di inviare il contenuto del commento
         * alla funzione saveComment in modo che venga controllato l'input,
         * venga salvata la stringa nel database se valutata corretta 
         * ed infine inserita all'interno della preview
         */
        
        var commentsResetButton=document.createElement('input');
        commentsResetButton.setAttribute('type',"reset");
        commentsResetButton.setAttribute('value',"Cancella");
        commentsForm.appendChild(commentsResetButton);
        //button reset che cancella il contenuto del form prima che venga inviato
        
        commentsDiv.appendChild(commentsForm);  
        //il commentsForm viene inserito nel DOM come child di commentsDiv
        
        loadOldComments();
           
    
    }
    
    
        function goNext(){
            
                <?php 
                $actualImageIndex=$_GET['index'];
                $actualImageIndex++;
				
				 if(isset($_GET['friend'])){
					 $username=$_GET['friend'];?>
					 username="<?php echo $username ?>";
               		
				<?php } else $username = $_SESSION['username'];
                
				
				$lista_file = caricaDirectory($username); ?>
                        
                actualImageIndex=<?php echo $actualImageIndex ?>;
                        
               <?php
                    dbConnect();
                     
                     $result= mysql_query("SELECT * FROM immagini WHERE username='".$username."'");
                     $numrows=  mysql_num_rows($result);
                     mysql_close();
                ?> 
                        
        <?php if($actualImageIndex>count($lista_file)-1){ ?>
               alert('Presentazione terminata. \n Se vuoi continuare a visualizzare le immagini scorri la galleria nel senso opposto. \n (INDIETRO)');
          <?php } else{ 
		  
		  	     ?>
                tempImg.src="<?php echo DIR_IMMAGINI_GRANDI ?>/preview_"+"<?php echo $lista_file[$actualImageIndex]; ?>";
				<?php if(isset($_GET['friend'])){?>
                location.replace("./userfriend.php?friend="+username+"&index="+actualImageIndex+"&src="+tempImg.src+"");  
				<?php } else {?>     
				location.replace("./pictures.php?username="+username+"&index="+actualImageIndex+"&src="+tempImg.src+""); 
				<?php } ?>
        <?php  } ?>
          
      } /*funzione goNext che permette di scorrere in avanti la preview.
            Nel caso in cui si arriva all'ultimo elemento della preview, un alert
            avvertira' l'utente su questo evento.*/
      
      function closeGallery(){
		  <?php if(isset($_GET['friend'])){?>
                location.replace("./userfriend.php?friend=<?php echo $_GET['friend']?>");  
				<?php } else {?>     
				location.replace("./pictures.php"); 
				<?php } ?>
        document.getElementById('content').removeChild(galleryDiv);
		
         }//funzione che semplicemente rimuove da content il child galleryDiv quando l'utente clicca sul pulsante chiudi

       function goBack(){
         
                <?php 
                $actualImageIndex=$_GET['index'];
                $actualImageIndex--;
				
				 if(isset($_GET['friend'])){
					 $username=$_GET['friend'];?>
					 username="<?php echo $username ?>";
               		
				<?php } else $username = $_SESSION['username'];
                
				
				$lista_file = caricaDirectory($username); ?>
                        
                actualImageIndex=<?php echo $actualImageIndex ?>;
                        
               <?php
                    dbConnect();
                     
                     $result= mysql_query("SELECT * FROM immagini WHERE username='".$username."'");
                     $numrows=  mysql_num_rows($result);
                     mysql_close();
                ?> 
                        
        <?php if($actualImageIndex<0){ ?>
               alert('Presentazione terminata. \n Se vuoi continuare a visualizzare le immagini scorri la galleria nel senso opposto. \n (INDIETRO)');
          <?php } else{ 
		  
		  	     ?>
                tempImg.src="<?php echo DIR_IMMAGINI_GRANDI ?>/preview_"+"<?php echo $lista_file[$actualImageIndex]; ?>";
				<?php if(isset($_GET['friend'])){?>
                location.replace("./userfriend.php?friend="+username+"&index="+actualImageIndex+"&src="+tempImg.src+"");  
				<?php } else {?>     
				location.replace("./pictures.php?username="+username+"&index="+actualImageIndex+"&src="+tempImg.src+""); 
				<?php } ?>
        <?php  } ?>
          
      }     //stesso scopo della funzione goNext, questa volta al contrario.
      
          
        function saveComment(){
         commentsFormData = commentsForm.commentsMessage.value;
		 
	<?php	 if(isset($_GET['friend'])){
					 $username=$_GET['friend'];?>
					 username="<?php echo $username ?>";
               		
				<?php } 
		 
		  if(isset($_GET['friend'])){?>
                location.replace("./userfriend.php?friend="+username+"&index="+actualImageIndex+"&src="+tempImg.src+"&commentsText="+commentsFormData+"&newComment=1");  
				<?php } else {?>     
				location.replace("./pictures.php?username="+username+"&index="+actualImageIndex+"&src=<?php echo $_GET['src'] ?>&commentsText="+commentsFormData+"&newComment=1"); 
				<?php } ?>
        }
   
        function checkCommentsForm(comment){  // Funzione che effettua il controllo client side sull'input inserito come commento
           
            var pattern=/[|+--=<>!=()%*]/;
                if (comment.search(pattern)==-1)
                    if(comment.length>1 && comment.length<140){ 
                          return true;
                       }else{
                        return false
                        }
                else{
                   return false
                    }
                
        }
          
         function loadOldComments(){
          var comment = "";
         <?php $commentsArray=loadComments($_GET['index']); ?>
                    
                        var newDiv = document.createElement("div");
   
                            newDiv.setAttribute("align","center");
                            newDiv.style.position="static";
                            newDiv.style.backgroundColor="#FBBE64";
                            newDiv.style.width="400px"; 
                             var dividingDiv = document.createElement("div");
                             dividingDiv.setAttribute("align","center");
							 dividingDiv.setAttribute("id","comments");
                             newDiv.appendChild(dividingDiv);  

                             commentsDiv.appendChild(newDiv);
		 document.getElementById("comments").innerHTML="<h4 align=\"center\">Commenti</h4><?php for($commentIndex=0;$commentIndex<count($commentsArray);$commentIndex++){  echo "<hr>".loadSingleComment($commentIndex,$commentsArray)."<br>";
						$divideString = explode(':',loadSingleComment($commentIndex,$commentsArray),-1);
			if($divideString[0]==$_SESSION['username'] | $_SESSION['administrator']==1){	 ?> <form method='GET'><?php if(isset($_GET['friend'])){echo "<p><input type='hidden' name='friend' value='".$_GET['friend']."'>";}else{echo "<p><input type='hidden' name='username' value='".$_GET['username']."'>";}?><input type='hidden' name='index' value='<?php echo $_GET['index'] ?>'><input type='hidden' name='src' value='<?php echo $_GET['src']?>'><input type='text' name='commentsText' ><input type='hidden' name='modifyComment' value='<?php  $newSrc= str_replace("http://localhost:8200/studenti/st106479/Public/Progetto Finale","",$_GET['src']); $newSrc=str_replace(DIR_IMMAGINI_GRANDI."/preview_","",$newSrc); $tempDir=str_replace(".","",DIR_IMMAGINI_GRANDI); $newSrc=str_replace($tempDir."/preview_","",$newSrc); echo $newSrc ?>'><input type='hidden' name='commentMessage' value='<?php echo loadSingleComment($commentIndex,$commentsArray)?>'><input type='submit' name='submitModifyComment' value='Modifica' onclick='return clientSideCommentsControl(this.form);'><input type='button' name='deleteComment' value='Elimina commento' onclick='location.replace(\"<?php if(isset($_GET['friend'])){echo "userfriend.php?friend=".$_GET['friend'];} else {echo "pictures.php?username=".$_GET['username'];} ?>&index=<?php echo $_GET['index'] ?>&src=<?php echo $_GET['src'] ?>&deleteComment=<?php  $newSrc= str_replace("http://localhost:8200/studenti/st106479/Public/Progetto Finale","",$_GET['src']); $newSrc=str_replace(DIR_IMMAGINI_GRANDI."/preview_","",$newSrc); $tempDir=str_replace(".","",DIR_IMMAGINI_GRANDI); $newSrc=str_replace($tempDir."/preview_","",$newSrc);  echo $newSrc ?>&commentMessage=<?php echo loadSingleComment($commentIndex,$commentsArray)?>\");'></p></form> <?php } }?>" 
         }
		 
		 </script>
	<?php	 function loadComments($id){

		if(isset($_GET['friend'])){
					 $username=$_GET['friend'];?>
					 username="<?php echo $username ?>";
               		
				<?php } else $username = $_SESSION['username'];
                
				
				$lista_file = caricaDirectory($username); 

        dbConnect();
        
        $sql1 = "SELECT comments FROM immagini WHERE src = '".$lista_file[$id]."'";
        $result= mysql_query($sql1);
        $oldComment = mysql_fetch_row($result);
        
        $commentsArray = explode('#',$oldComment[0],-1);
        mysql_close();
        
        return $commentsArray;
   

}

function loadSingleComment($i,$commentsArray){
    
    $string = $commentsArray[$i];
    
        return $string;
}
    
    ?>

