<?php

    function loadUsers() {
        dbConnect();
        $result = mysql_query("SELECT username,administrator, validated FROM utenti");
        $contenuto = Array();
        while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
             $contenuto[] =  $row['username'];  
			 $contenuto[] =  $row['administrator'];
			 $contenuto[] =  $row['validated'];
			 
        }
         mysql_close();
        return $contenuto;
    }
	
	
	 function caricaDirectory($username) {
        dbConnect();
        $result = mysql_query("SELECT src FROM immagini WHERE username = '".$username."'");
        $contenuto = Array();
        while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
             $contenuto[] =  $row['src'];  
        }
        $dbLength = mysql_num_rows($result);
         mysql_close();
        return $contenuto; 
    }
        
        // funzione che genera un link verso l'immagine $file dell'utente $username con indice $index 
        function generaLinkImmagine($username,$index, $file) {
            
           return "<a href=\"./pictures.php?username="
    . $username . "&amp;index="
    . $index ."&amp;src=".DIR_IMMAGINI_GRANDI."/preview_".$file."\">" 
    . "<img alt=\"image\" src=\"" . DIR_IMMAGINI_PICCOLE . "/small_" 
    . $file . "\">"
    . "</a>";
            
        }
		
		function generaLinkImmagineFriend($username,$index, $file) {
            
           return "<a href=\"./userfriend.php?friend="
    . $username . "&amp;index="
    . $index ."&amp;src=".DIR_IMMAGINI_GRANDI."/preview_".$file."\">" 
    . "<img alt=\"image\" src=\"" . DIR_IMMAGINI_PICCOLE . "/small_" 
    . $file . "\">"
    . "</a>";
            
        }

        function controllaFormato($nomefile) {
            global $formati_immagine;
            foreach ($formati_immagine as $formato)
                if (strrpos($nomefile, $formato))
                    return TRUE;
                return FALSE; // nessun formato trovato
         }
         
        function controllaTipo($tipo) {
            global $tipi_immagine;
            foreach ($tipi_immagine as $formato)
                if (strpos($tipo, $formato)===0)
                    return TRUE;
                return FALSE; // nessun tipo trovato
            }
?>
