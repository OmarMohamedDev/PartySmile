<?php
$flag=true;
$emptyString = "";

$_POST['uname'] = stripslashes($_POST['uname']);
$_POST['passwd'] = stripslashes($_POST['passwd']);

$pattern = '/[|+--\'=<>!=()%*]/i';

  $qry = "SELECT username, password FROM utenti WHERE username = '".$_POST['uname']."'";
    $check = mysql_query($qry);
    $info = mysql_fetch_row($check);
	
	$info[0] = stripslashes($info[0]);
	$info[1] = stripslashes($info[1]);

	
    
    if((preg_match($pattern,$_POST["uname"])===0))
		if((strlen($_POST["uname"])>=5) && (strlen($_POST["uname"])<=15))
			if((preg_match($pattern,$_POST["passwd"])===0))
				if((strlen($_POST["passwd"])>=5) && (strlen($_POST["passwd"])<=15))
					if ($_POST['uname'] == $info[0])
						if ((md5($_POST['passwd'])) == $info[1])
							$flag=true;
						else{
							session_destroy();
							$flag=false;
							$errorMessage2="[SERVER-SIDE CHECK] Password non corretta. \n Perfavore riprova a digitare la tua password.";
    						}	
					else{
						session_destroy();
						$flag=false;
        				$errorMessage2="[SERVER-SIDE CHECK] Username non corretto.\nPerfavore riprova a digitare il tuo username o effettua la procedura di registrazione se è la prima volta che visiti PartySmile.";
  					    } 
				else{
					session_destroy();
					$flag=false;
					$errorMessage2="[SERVER-SIDE CHECK] La password deve avere una lunghezza compresa tra 5 e 15 caratteri.";
					}
			else{
				session_destroy();
				$flag=false;
				$errorMessage2="[SERVER-SIDE CHECK] La password non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
				}
		else{
			session_destroy();
			$flag=false;
			 $errorMessage2="[SERVER-SIDE CHECK] L'username deve avere una lunghezza compresa tra 5 e 15 caratteri.";
			}	
	else{
		session_destroy();
		$flag=false;
		 $errorMessage2="[SERVER-SIDE CHECK] L'username non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
		}
	
?>