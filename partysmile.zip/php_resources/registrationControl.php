<?php

$flag=true;
$emptyString = "";
    
    // si verifica la presenza dell'username inserito all'interno del database
	
	$qry = "SELECT username FROM utenti WHERE username = '".$_POST['uname']."'";
    $check = mysql_query($qry);
    $info = mysql_fetch_row($check);
	
	$info[0]= stripslashes($info[0]);
	
	$qry2 = "SELECT email FROM utenti WHERE email = '".$_POST['email']."'";
    $check2 = mysql_query($qry2);
    $info2 = mysql_fetch_row($check2);
	
	$info2[0]= stripslashes($info2[0]);
	
	$pattern = '/[|+--\'=<>!=()%*]/i';
	$patternMail = '/\S+@\S+\.\S+/';
 
    if ($_POST['uname'] != $info[0] | $_POST['uname'] == $emptyString) 
		if ($_POST['email'] != $info2[0] | $_POST['email'] == $emptyString)
			if((preg_match($pattern,$_POST["uname"])===0))
				if((strlen($_POST["uname"])>=5) && (strlen($_POST["uname"])<=15))
					if((preg_match($pattern,$_POST["passwd"])===0))
						if((strlen($_POST["passwd"])>=5) && (strlen($_POST["passwd"])<=15))
							if((preg_match($patternMail,$_POST["email"])===1))
								$flag=true;
							else{
								$flag=false;
								$errorMessage2="[SERVER-SIDE CHECK] Inserisci un indirizzo email con un formato corretto. Esempio: (studente@ateneo.com)";
							 	}
						else{ 
							$flag=false;
							$errorMessage2="[SERVER-SIDE CHECK] La password deve avere una lunghezza compresa tra 5 e 15 caratteri.";
							}
					else{
						$flag=false;
						$errorMessage2="[SERVER-SIDE CHECK] La password non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
						}
				else{
					$flag=false;
					 $errorMessage2="[SERVER-SIDE CHECK] L'username deve avere una lunghezza compresa tra 5 e 15 caratteri.";
					}
			else{
				$flag=false;
				 $errorMessage2="[SERVER-SIDE CHECK] L'username non può contenere i seguenti caratteri: |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
				}
		else{
			$flag=false;
			$errorMessage2="[SERVER-SIDE CHECK] Email già utilizzata per un altro account. E' possibile registrare solo un account per ogni indirizzo email. Perfavore, inserisci un altro indirizzo di posta elettronica."; 
		
    } 
	else{
		$flag=false;
        $errorMessage2="[SERVER-SIDE CHECK] Username già utilizzato da un altro utente. Perfavore inserisci un altro username.";
    } 
	
	 
	 ?>