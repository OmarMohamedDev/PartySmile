<?php

//implementazione del controllo e del caricamento dell'immagine del profilo

			require_once("./php_resources/config.php");
            
            function controllaTipo($tipo) {
            global $tipi_immagine;
            foreach ($tipi_immagine as $formato)
                if (strpos($tipo, $formato)===0)
                    return TRUE;
                return FALSE; // nessun tipo trovato
            }
            
                $tmp_nome = $_FILES["nomefile"]["tmp_name"];
                $tipo = $_FILES["nomefile"]["type"];
                $nome = $_SESSION['username']."Avatar.jpg";
            if (!controllaTipo($tipo)) $errorMessage2="File di tipo sconosciuto\n";
            	if(move_uploaded_file($tmp_nome, DIR_AVATAR . "/TEMP" . $nome)) { 
                
                $immagine_sorgente = imagecreatefromjpeg(DIR_AVATAR . "/TEMP" . $nome);
                $larghezza_sorgente = imagesx($immagine_sorgente);
                $altezza_sorgente = imagesy($immagine_sorgente);
                $larghezza_nuova = 200;
                $altezza_nuova = 250;
                $immagine_nuova = imagecreatetruecolor($larghezza_nuova, $altezza_nuova);
                imagecopyresampled($immagine_nuova, $immagine_sorgente, 0, 0, 0, 0, 
				$larghezza_nuova, $altezza_nuova, $larghezza_sorgente, $altezza_sorgente);
                imagejpeg($immagine_nuova, DIR_AVATAR."/".$nome,100); 
                    
                    if (file_exists(DIR_AVATAR . "/TEMP" . $nome))  
                            unlink (DIR_AVATAR . "/TEMP" . $nome); 
                    
                    header("Location: personalinformation.php");
                    
                    }
            else
                $errorMessage2="Il sistema non è riuscito a spostare il file, controlla i permessi\n";
			
			
?>