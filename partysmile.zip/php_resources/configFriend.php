<?php
    // dati di configurazione per i path ed i formati delle immagini di un utente amico
    define("DIR_AVATAR", "./users/".$_GET['friend']."/avatar");
	define("DIR_IMMAGINI_PICCOLE", "./users/".$_GET['friend']."/pictures/small");
	define("DIR_IMMAGINI_GRANDI", "./users/".$_GET['friend']."/pictures/big");
	define("DIR_IMMAGINI", "./users/".$_GET['friend']."/pictures");
    $formati_immagine = array(".jpg", ".gif", ".png");
    $tipi_immagine = array("image/jpeg", "image/gif", "image/
    png");
?>