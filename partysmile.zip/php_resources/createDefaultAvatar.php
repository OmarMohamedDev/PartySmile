<?php 

 $larghezza_nuova = 200;
 $altezza_nuova = 250;
 $immagine_nuova = imagecreatetruecolor($larghezza_nuova, $altezza_nuova);
 imagejpeg($immagine_nuova, "./users/".$_POST['uname']."/avatar/".$_POST['uname']."Avatar.jpg",100); 
 ?>