<?php

$dbFlag=true;

?> 
      