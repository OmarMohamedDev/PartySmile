<?php 
     require './check_session.php';
     require './dbConn.php';
	
	dbConnect();
	$qry = "DELETE FROM `dbomarmohamed`.`richiesteamicizia` WHERE `richiesteamicizia`.`sender` = '".$_GET['sender']."' AND`richiesteamicizia`.`receiver` = '".$_SESSION['username']."' ";
	$check = mysql_query($qry);
	mysql_close();
	
	header("Location: ../notice.php");
?>