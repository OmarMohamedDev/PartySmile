<?php
$flag=true;

$pattern = '/[|+--\'=<>!=()%*]/i';
      
			if((preg_match($pattern,$_POST["newStatusMessage"])===0))
				if((strlen($_POST["newStatusMessage"])>=1) && (strlen($_POST["newStatusMessage"])<=140))
							$flag=true;
				else{
					$flag=false;
					$errorMessage2="[SERVER-SIDE CHECK] Il nuovo messaggio di stato deve avere una lunghezza compresa tra 1 e 140 caratteri.";
					}
			else{
				$flag=false;
				$errorMessage2="[SERVER-SIDE CHECK] Il nuovo messaggio di stato non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,'";
				}
	
?>
