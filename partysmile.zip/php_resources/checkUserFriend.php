<?php
if ($_GET['friend']==$_SESSION['username']) {
?>
<script type="text/javascript">
location.replace("home.php")
</script>
<?php 
}