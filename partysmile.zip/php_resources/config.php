<?php
    // dati di configurazione per i path ed i formati delle immagini dell'utente loggato
    define("DIR_AVATAR", "./users/".$_SESSION['username']."/avatar");
	define("DIR_IMMAGINI_PICCOLE", "./users/".$_SESSION['username']."/pictures/small");
	define("DIR_IMMAGINI_GRANDI", "./users/".$_SESSION['username']."/pictures/big");
	define("DIR_IMMAGINI", "./users/".$_SESSION['username']."/pictures");
    $formati_immagine = array(".jpg", ".gif", ".png");
    $tipi_immagine = array("image/jpeg", "image/gif", "image/
    png");
?>