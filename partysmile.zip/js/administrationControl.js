//Funzione che verifica la correttezza delle stringhe inserite nella pagina di amministrazione

function clientSideAdministrationControl(username){

var pattern=/[|+--=<>!=()%*]/;

if (username.search(pattern)==-1)
    if(username.length>=5 && username.length<=15)
        		 return true;
    else{
        document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] L\'username deve avere una lunghezza compresa tra 5 e 15 caratteri.';
        return false;
        }
else{
    document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] L\'username non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*';
    return false;
    }
	
}