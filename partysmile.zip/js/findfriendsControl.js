//Funzione che verifica la correttezza delle stringhe inserite nella pagina di ricerca amici

function clientSideFindFriendsControlUsername(username){

var pattern=/[|+--=<>!=()%*]/;

if (username.search(pattern)==-1)
    if(username.length>=5 && username.length<=15)
        		 return true;
    else{
        document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] L\'username deve avere una lunghezza compresa tra 5 e 15 caratteri.';
        return false;
        }
else{
    document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] L\'username non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*';
    return false;
    }
	
}


function clientSideFindFriendsControlName(name){

var pattern=/[|+--=<>!=()%*]/;

if (name.search(pattern)==-1)
        		 return true;

else{
    document.getElementById("errorMessage").innerHTML ='Il nome della persona che stai cercando non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*';
    return false;
    }
	
}

function clientSideFindFriendsControlSurname(surname){

var pattern=/[|+--=<>!=()%*]/;

if (surname.search(pattern)==-1)
        		 return true;

else{
    document.getElementById("errorMessage").innerHTML ='Il cognome della persona che stai cercando non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*';
    return false;
    }
	
}

function clientSideFindFriendsControlEmail(email){
	
var patternMail = /\S+@\S+\.\S+/;


 if (email.search(patternMail)==0)
        		 return true;
    else{
        document.getElementById("errorMessage").innerHTML = 'Inserisci un indirizzo email con un formato corretto. Esempio: (studente@ateneo.com).';
        return false;
        }
		
}

function clientSideFindFriendsControlActualCity(actualcity){
	
var pattern=/[|+--=<>!=()%*]/;

if (actualcity.search(pattern)==-1)
        		 return true;
    else{
       document.getElementById("errorMessage").innerHTML ='Il nome della città dove la persona che ricerchi vive attualmente non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,\'';
        return false;
        }
	

}