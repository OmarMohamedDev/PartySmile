/*Funzione che verifica la correttezza della stringa
  *inserita come commento mediante un espressione regolare
  *che controlla la presenza di caratteri speciali non permessi dalle specifiche
  *e poi tramite un if che controlla che la lunghezza sia adeguata alle suddette
  *direttive.*/

function clientSideCommentsControl(commentsText){
	
var pattern=/[|+--\'=<>!=()%*]/;
if (commentsText.search(pattern)==-1)    
    if(commentsText.length>1 && commentsText.length<140)  
         return true;
    else{
        document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] La lunghezza del messaggio deve essere compreso tra 1 e 140 caratteri.';
        return false;
        }
else{
    document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] Non si possono utilizzare i seguenti caratteri: \n |, +, --, =, <, >, !=, (, ),%, *,\'';
    return false;
    }
}
