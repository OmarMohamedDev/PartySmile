//Funzione che verifica client-side la correttezza delle stringhe inserite come dati di login 

function clientSideFirstConnectionControl(username,password,nomehost,nomedb){ 

var pattern=/[|+--=<>!=()%*]/;

if (username.search(pattern)==-1)
		if (password.search(pattern)==-1)
    		if(nomehost.length>=5 && nomehost.length<=50)
				if (nomedb.search(pattern)==-1)
        		 return true;
			else{
				document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] Il nome del database non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*';
				return false;
				}
		else{
			document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] Il nome host deve avere una lunghezza compresa tra 5 e 50 caratteri.';
			return false;
			}
	else{
		document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] La password non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*';
		return false;
		}
else{
		document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] L\'username non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*';
		return false;
		}
	
}