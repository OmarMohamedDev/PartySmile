//Funzione che verifica client-side la correttezza delle stringhe inserite nella pagina di controllo utente

function clientSideInformationControl(password,email,name,surname,birthdate,birthcity,actualcity,sentimentalsituation){

var pattern=/[|+\'--=<>!=()%*]/;
var patternMail = /\S+@\S+\.\S+/;
var patternDate = /^\d{2}[-]\d{2}[-]\d{4}$/;

if (sentimentalsituation.search(pattern)==-1)
	if (actualcity.search(pattern)==-1)
		if (birthcity.search(pattern)==-1)
			if (surname.search(pattern)==-1)
				if (name.search(pattern)==-1)
					if (birthdate.search(patternDate)==0)
						if (password.search(pattern)==-1)
							if(password.length>=5 && password.length<=15)
								if (email.search(patternMail)==0)
								 return true;
								 else{
									 document.getElementById("errorMessage").innerHTML = '[CLIENT-SIDE CHECK] Inserisci un indirizzo email con un formato corretto. Esempio: (studente@ateneo.com).';
								return false;
								}
						   else{
								document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] La password deve avere una lunghezza compresa tra 5 e 15 caratteri.';
								return false;
							   }
						else{
							document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] La password non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,\'';
							return false;
							}
					else{
						document.getElementById("errorMessage").innerHTML = '[CLIENT-SIDE CHECK] Inserisci la tua data di nascita con un formato corretto. Esempio: (GG-MM-AAAA).';
								return false;
						}
				else{
					document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] Il tuo nome reale non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,\'';
					return false;
					}
			else{
					document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] Il tuo cognome non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,\'';
					return false;
					}
		else{
					document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] Il nome della tua città di nascita non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,\'';
					return false;
					}
	else{
					document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] Il nome della città dove vivi attualmente non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,\'';
					return false;
					}		
else{
					document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] La descrizione della tua situazione sentimentale attuale non può contenere i seguenti caratteri: \n |, +, -, --, =, <, >, !, !=, (, ),%,*,\'';
					return false;
					}
	
}