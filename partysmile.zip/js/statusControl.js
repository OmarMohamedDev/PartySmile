//Funzione che verifica client-side la correttezza delle stringe messaggio di stato

function clientSideStatusControl(newStatusMessage){

var pattern=/[|+--\'=<>!=()%*]/;  
if (newStatusMessage.search(pattern)==-1)
    if(newStatusMessage.length>1 && newStatusMessage.length<140)
         return true;
    else{
        document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] La lunghezza del messaggio deve essere compreso tra 1 e 140 caratteri. ';
        return false;
        }
else{
    document.getElementById("errorMessage").innerHTML ='[CLIENT-SIDE CHECK] Non si possono inoltre utilizzare i seguenti caratteri: \n |, +, --, =, <, >, !=, (, ),%, *,\'';
    return false;
    }
}