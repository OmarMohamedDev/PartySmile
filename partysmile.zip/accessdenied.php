<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>PartySmile - Just have fun! - Pagina non raggiungibile</title>
<link href="./CSS/sitestyle.css" rel="stylesheet" type="text/css">
</head>

<body>

<div class="container">
  <?php require("header.php"); ?>
  <div class="content">
    <h1>Accesso negato</h1>
    <p>Non possiedi i permessi necessari per visionare questa pagina di PartySmile.</p>
    <p>Torna alla pagina principale del tuo <a href="home.php">profilo</a>.</p>
    <!-- end .content --></div>
  <?php require("footer.php");?>
  <!-- end .container --></div>
</body>
</html>